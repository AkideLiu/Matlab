% initialize vector A
A=[-10:0.5:10];