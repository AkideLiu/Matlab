clc;
clear;
close all;

% declare vector A and Vector B
A = [1:10];
B = [11:20];